<template>
  <div class="container">
    <h1>All Blog Posts</h1>

    <select v-model="selectedCategory" class="category-filter">
      <option value="">All Categories</option>
      <option value="tech">Tech</option>
      <option value="design">Design</option>
      <option value="sport">Sport</option>
    </select>

    <div v-if="filteredPosts.length > 0" class="post-list">
      <div v-for="post in filteredPosts" :key="post.id" class="post-card">
        <NuxtLink :to="'/blog/' + post.id" class="post-title">
          {{ post.title }}
        </NuxtLink>
        <p class="post-author"><strong>Author:</strong> {{ post.author }}</p>
        <p class="post-snippet">{{ post.snippet }}</p>
      </div>
    </div>

    <p v-else class="no-results">No posts found.</p>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'

const posts = ref([])
const selectedCategory = ref('')

onMounted(async () => {
//   const res = await fetch('http://localhost:1337/api/posts')
const config = useRuntimeConfig()
const res = await fetch(`${config.public.API_BASE}/posts`)          //THIS MAKES IT SO IT CAN WORK ON ANY PORT      NOT JUST 1337
  const data = await res.json()
  posts.value = data.data
})

const filteredPosts = computed(() => {
  if (!selectedCategory.value) return posts.value
  return posts.value.filter(post =>
    post.category?.toLowerCase() === selectedCategory.value.toLowerCase()
  )
})
</script>

<style scoped>
.container {
  max-width: 800px;
  margin: auto;
  padding: 20px;
  background-color: #B6B7E6;
  min-height: 100vh;
  border-radius: 10px;
}

h1 {
  color: #333;
  margin-bottom: 20px;
}

.category-filter {
  margin-bottom: 20px;
  padding: 8px;
  border-radius: 5px;
  border: 1px solid #333;
  background-color: #FFFBD4;
  color: #333;
}

.post-list {
  display: flex;
  flex-direction: column;
  gap: 20px;
}

.post-card {
  padding: 16px;
  border: 1px solid #333;
  border-radius: 6px;
  background-color: #FFFBD4;
  box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
}

.post-title {
  font-size: 1.2em;
  color: #333;
  text-decoration: none;
  font-weight: bold;
}

.post-title:hover {
  color: #000;
  text-decoration: underline;
}

.post-author,
.post-snippet {
  margin-top: 6px;
  color: #333;
}

.no-results {
  color: #900;
  font-weight: bold;
  background-color: #FFFBD4;
  padding: 10px;
  border-radius: 5px;
}

body {
  background-color: #B6B7E6;
}
</style>
