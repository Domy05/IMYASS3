<template>
  <div class="container">
    <div v-if="post" class="post">
      <h1>{{ post.title }}</h1>
      <p><strong>Author:</strong> {{ post.author }}</p>

      <div v-for="(block, index) in post.content" :key="index">
        <p v-if="block.type === 'paragraph'">
          {{ block.children[0].text }}
        </p>
      </div>

      <!-- Back button -->
      <router-link to="/" class="btn">← Back to Home</router-link>
    </div>

    <div v-else class="loading">
      <p>Loading post...</p>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useRoute } from 'vue-router'

const post = ref(null)
const route = useRoute()

onMounted(async () => {
//   const res = await fetch(`http://localhost:1337/api/posts`)
const config = useRuntimeConfig()
const res = await fetch(`${config.public.API_BASE}/posts`)          //THIS MAKES IT SO IT CAN WORK ON ANY PORT      NOT JUST 1337
  const data = await res.json()
  post.value = data.data.find(p => p.id == route.params.id)
})
</script>

<style scoped>
.container {
  background-color: #FFFBD4;
  min-height: 100vh;
  padding: 2rem;
  display: flex;
  /* justify-content: center; */
  /* align-items: center; */
}

/* .post {
  background-color: #FFFBD4;
  padding: 2rem;
  border-radius: 10px;
  max-width: 600px;
  width: 100%;
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
  color: #333;
} */

h1 {
  margin-bottom: 1rem;
  color: #333;
}

p {
  margin: 0.5rem 0;
}

.btn {
  display: inline-block;
  margin-top: 2rem;
  padding: 0.5rem 1rem;
  background-color: #B6B7E6;
  color: #333;
  text-decoration: none;
  border-radius: 5px;
  font-weight: bold;
  border: 2px solid #333;
  transition: background-color 0.3s ease;
}

.btn:hover {
  background-color: #a5a6d0;
}

.loading {
  color: #FFFBD4;
  font-size: 1.2rem;
}
</style>