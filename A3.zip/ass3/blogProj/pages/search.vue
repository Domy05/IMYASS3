<template>
  <div class="container">
    <h1>Search Posts</h1>
    <input
      v-model="query"
      class="search-input"
      placeholder="Search by title or author"
    />

    <div v-if="filteredPosts.length > 0" class="post-list">
      <div v-for="post in filteredPosts" :key="post.id" class="post-card">
        <NuxtLink :to="'/blog/' + post.id" class="post-title">
          <h3>{{ post.title }}</h3>
        </NuxtLink>
        <p class="post-author"><strong>Author:</strong> {{ post.author }}</p>
      </div>
    </div>

    <p v-else class="no-results">No results found.</p>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'

const posts = ref([])
const query = ref('')

onMounted(async () => {
//   const res = await fetch('http://localhost:1337/api/posts')
const config = useRuntimeConfig()
const res = await fetch(`${config.public.API_BASE}/posts`)          //THIS MAKES IT SO IT CAN WORK ON ANY PORT      NOT JUST 1337
  const data = await res.json()
  posts.value = data.data
})

const filteredPosts = computed(() => {
  const q = query.value.toLowerCase()
  return posts.value.filter(p => {
    const title = p.title?.toLowerCase() || ''
    const author = p.author?.toLowerCase() || ''
    return title.includes(q) || author.includes(q)
  })
})
</script>

<style scoped>
.container {
  max-width: 800px;
  margin: auto;
  padding: 20px;
  background-color: #B6B7E6;
  min-height: 100vh;
  border-radius: 10px;
}

h1 {
  color: #333;
  margin-bottom: 20px;
}

.search-input {
  width: 100%;
  padding: 8px;
  margin-bottom: 20px;
  border: 1px solid #333;
  border-radius: 5px;
  background-color: #FFFBD4;
  color: #333;
}

.post-list {
  display: flex;
  flex-direction: column;
  gap: 20px;
}

.post-card {
  padding: 16px;
  border: 1px solid #333;
  border-radius: 6px;
  background-color: #FFFBD4;
  box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
}

.post-title {
  color: #333;
  text-decoration: none;
  font-weight: bold;
}

.post-title:hover {
  text-decoration: underline;
  color: #000;
}

.post-author {
  margin-top: 6px;
  color: #333;
}

.no-results {
  color: #900;
  font-weight: bold;
  background-color: #FFFBD4;
  padding: 10px;
  border-radius: 5px;
}

body {
  background-color: #B6B7E6;
}
</style>